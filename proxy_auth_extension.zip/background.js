
var config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "http",
                host: "130.255.65.186",
                port: parseInt(12323)
            },
            bypassList: ["localhost"]
        }
    };

chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

chrome.webRequest.onAuthRequired.addListener(
    function(details) {
        return {
            authCredentials: {
                username: "14acc5b4cccca",
                password: "8b9286578b"
            }
        };
    },
    {urls: ["<all_urls>"]},
    ["blocking"]
);
